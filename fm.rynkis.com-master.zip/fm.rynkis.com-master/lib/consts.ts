
export const MS_1_MIN = 60 * 1000
export const MS_5_MINS = 5 * MS_1_MIN
export const MS_1_HOUR = 60 * MS_1_MIN
export const MS_24_HOURS = 24 * MS_1_HOUR
